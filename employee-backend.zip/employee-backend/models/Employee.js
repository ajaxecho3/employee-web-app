const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let Employee = new  Schema({
   Name: {
       type: String
   },
   Position: {
       type: String
   },
   Age: {
       type: Number
   },
   
},{
    collection: 'employee_info'
}
);
module.exports = mongoose.model('Employee', Employee)